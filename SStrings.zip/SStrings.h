#pragma once
#include <string>
using namespace std;



bool StartWith(string str, string desired)
{
    for (int i = 0; i < str.length(); i++)
    {
        int num = 0;
        if (str[i] == desired[i])
        {
            num += 1;
            if (num = desired.length())
            {
                return true;
                break;
            }
        }
        else
        {
            return false;
            break;
        }
    }
}
/*
Method "StartWith()" - checks the string you specify to see if it contains another
    string you are looking for.
    str - The full string in which the search string will be searched.
    desired - The string that the method will look for, and if it is found,
    it will return true
*/



char* Split(string SplitSymbol, string Split, string Split_mode = "f")
{
    int size = Split.length();
    char* result = new char[size + 1];
    int j = 0;
    char SSymbol = SplitSymbol[0];
    if (Split_mode == "f")
    {
        for (int i = 0; i < size; i++)
        {
            if (Split[i] != SSymbol)
                result[j++] = Split[i];
            else
                break;
        }
    }
    result[j] = '\0'; // ����� ������
    return result;
}
/*
Method "Split()" - It cuts a string and returns you the string up to the character that is specified 
    as the first argument to the method. If no exceptions are thrown, the method will return a char 
    array.
*/



bool Contain(string str, string desired)
{
    return true;
}
/*
There will be a method here that I will show in the next "update"
*/